package com.example.jareduc;

public class Login {
}
