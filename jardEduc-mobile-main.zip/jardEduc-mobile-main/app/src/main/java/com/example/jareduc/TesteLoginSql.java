package com.example.jareduc;
import java.sql.*;
import java.util.Scanner;

public class TesteLoginSql {


    public static class LoginSystem {
        public static void main(String[] args) {
            String url = "jdbc:mysql://localhost:3306/nome_do_banco?useSSL=false";
            String username = "usuario_do_banco"; //não tem usuario
            String password = "senha_do_banco"; //não tem senha

            // Obter entrada do usuário
            Scanner scanner = new Scanner(System.in);
            System.out.print("Digite o nome de usuário: ");
            String inputUsername = scanner.nextLine();
            System.out.print("Digite a senha: ");
            String inputPassword = scanner.nextLine();

            try {
                // Conectar ao banco de dados
                Connection connection = DriverManager.getConnection(url, username, password);

                // Consulta para verificar as credenciais
                String query = "SELECT * FROM usuarios WHERE username = ? AND senha = ?";
                PreparedStatement statement = connection.prepareStatement(query);
                statement.setString(1, inputUsername);
                statement.setString(2, inputPassword);

                // Executar a consulta
                ResultSet resultSet = statement.executeQuery();

                if (resultSet.next()) {
                    System.out.println("Login bem-sucedido!");
                } else {
                    System.out.println("Nome de usuário ou senha incorretos!");
                }

                // Fechar conexão e recursos
                resultSet.close();
                statement.close();
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }

}
