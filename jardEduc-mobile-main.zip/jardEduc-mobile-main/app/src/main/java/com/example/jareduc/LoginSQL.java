package com.example.jareduc;

import android.os.StrictMode;

import java.sql.*;

public class LoginSQL {
    private static final String DB_URL = "jdbc:sqlserver://some.com;databaseName=bd_jardimdaeducacao;integratedSecurity=true";
    private static Object mContext;
    private static Object Context;
    private static Object mStringConnectionURL;
    private static String mStringServerIpnome;
    private static String mStringDatabase;
    private static String mStringemail;
    private static String mStringsenha;

    public static void main(String[] args) {
        // Criar uma conexão com o banco de dados usando autenticação do Windows
        try (Connection conn = DriverManager.getConnection(DB_URL)) {
            // A conexão será estabelecida usando as credenciais do usuário do Windows atual


                    StrictMode.ThreadPolicy mPolicy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(mPolicy);

                    //testar se foi copiado implementado o drive/biblioteca jtds
                    Class.forName("net.sourceforge.jtds.jdbc.Driver");
                    // montagem da string de conexao com o banco
                    //concatenar as string

                    mStringConnectionURL = "jdbc:jtds:sqlserver://" + mStringServerIpnome +
                            ";databaseName=" + mStringDatabase +
                            ";email = " + mStringemail +
                            ";senha = " + mStringsenha + ";";
                    // para o localhost e o MYSLQ voce precisa de uma outra string de conexão
                    // fazer com que o objeto de conexao obtenha a conexao a partir do gerenciamento de driver

                    // Executar ações após o login bem-sucedido
                    System.out.println("Login bem-sucedido!");
                } catch (ClassNotFoundException e) {
                    throw new RuntimeException(e);
                } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }}
