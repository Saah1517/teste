package com.example.jareduc;

public class LoginForm {
}
