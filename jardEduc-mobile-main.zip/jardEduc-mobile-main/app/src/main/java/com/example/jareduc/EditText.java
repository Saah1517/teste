package com.example.jareduc;

public class EditText {
    public CharSequence getText() {
        return null;
    }

    public void setOnEditorActionListener(MainActivity.EditTextAction editTextAction) {
    }
}
